export { default as StartGame } from './start-game/index';
export { default as Game } from './game/index';