export const colors = {
    primary: "#97A1D8",
    secondary: "#C4C9E9",
    background: "#F5F5F5",
    text: "#212121",
    white: "#fff",
    black: "#000"
}